---
name: Sacred Sovereignty
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#20201f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353535'
  on-surface: '#e5e2e1'
  on-surface-variant: '#d6c2ba'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#9f8d85'
  outline-variant: '#52443d'
  surface-tint: '#fbb796'
  primary: '#fbb796'
  on-primary: '#4e250e'
  primary-container: '#c78a6b'
  on-primary-container: '#4e250d'
  inverse-primary: '#855237'
  secondary: '#fff9ef'
  on-secondary: '#3a3000'
  secondary-container: '#ffdb3c'
  on-secondary-container: '#725f00'
  tertiary: '#ffb3b4'
  on-tertiary: '#680016'
  tertiary-container: '#ff636f'
  on-tertiary-container: '#680016'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdbcb'
  primary-fixed-dim: '#fbb796'
  on-primary-fixed: '#341100'
  on-primary-fixed-variant: '#693b22'
  secondary-fixed: '#ffe16d'
  secondary-fixed-dim: '#e9c400'
  on-secondary-fixed: '#221b00'
  on-secondary-fixed-variant: '#544600'
  tertiary-fixed: '#ffdad9'
  tertiary-fixed-dim: '#ffb3b4'
  on-tertiary-fixed: '#40000a'
  on-tertiary-fixed-variant: '#920023'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353535'
typography:
  display-lg:
    fontFamily: Space Mono
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -1px
  headline-lg:
    fontFamily: Space Mono
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-md:
    fontFamily: Space Mono
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  body-lg:
    fontFamily: Fira Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Fira Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  headline-lg-mobile:
    fontFamily: Space Mono
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
spacing:
  pixel_unit: 4px
  gutter: 16px
  margin_mobile: 16px
  margin_desktop: 32px
  container_max: 1200px
---

## Brand & Style
The design system draws from the 16-bit JRPG golden era, specifically the "Chrono Trigger" and "Final Fantasy VI" aesthetic, but re-centered entirely on the Yoruba Kingdom of Oyó. The style is **Retro-Tactile**, blending pixel-art precision with organic, hand-painted textures like terracotta, thatch, and adire indigo fabrics.

The atmosphere is one of **Sacred Fantasy**: vibrant and welcoming, yet layered with mystery. The UI should feel like a physical artifact from the kingdom—carved by a master woodworker or forged by a blacksmith. Avoid all Western medieval tropes; there are no stone castles here, only grand palaces of wood, earth, and spirit. Every element reflects the dignity of the Orishas and the bustling energy of the marketplace.

## Colors
The palette is rooted in the earth and the sacred colors of the Orishas. 
- **Primary (Terra-cotta):** Used for main structural elements, containers, and backgrounds to ground the UI in the architecture of Oyó.
- **Secondary (Oxum Gold):** Reserved for highlights, legendary items, and "active" states to signify divinity and wealth.
- **Tertiary (Ogum Red/Green):** Used for interactive signals and health/stamina bars.
- **Neutral (Exu Black):** A deep, saturated charcoal used for high-contrast text backgrounds and shadows, providing the necessary depth for a 16-bit aesthetic.

## Typography
To emulate 16-bit pixel fonts while maintaining modern accessibility, we use a tiered system:
- **Headlines:** Use **Space Mono** to mimic the blocky, carved nature of pixel-art titles. It should be styled with a "dropped shadow" effect (1px offset) or a thick 2px outline in `exu-black` to feel like an in-game UI.
- **Body Text:** **Fira Sans** provides the necessary legibility for long dialogue or item descriptions, as its humanist traits feel more "hand-written" than purely mechanical fonts.
- **Data/UI Labels:** **JetBrains Mono** is used for stats, inventory counts, and technical labels, echoing the precise nature of classic RPG menus.

## Layout & Spacing
The layout follows a **Fixed Pixel Grid** logic. Every spacing value must be a multiple of **4px** to ensure that "pixel" alignments never look blurry or off-grid. 

Menus should be centered "floating" windows rather than full-screen edges. Use generous inner padding (24px) to allow room for decorative borders. On mobile, use a single-column layout where "wooden tablet" containers stack vertically. On desktop, use a 3-column "Inventory Style" grid where sidebars hold character stats and the main area holds the narrative or map.

## Elevation & Depth
Depth is achieved through **Hard Layering** and **Pixel Shadows**, not soft blurs.
- **Level 0 (Earth):** The background texture (Mata Green or Terra-cotta).
- **Level 1 (Surface):** "Wooden" containers with a 2px inner highlight on the top and left edges, and a 2px dark "burnt" shadow on the bottom and right edges.
- **Level 2 (Pop-ups):** Items like dialogue boxes should have a thick 4px border (alternating colors like adire patterns) and a solid black 8px offset shadow to create "pop."
- **Textures:** Apply a subtle noise or "dithering" pattern to large flat surfaces to simulate the hand-painted feel of 16-bit hardware.

## Shapes
In keeping with the 16-bit aesthetic, the design system uses **Sharp (0px)** corners. "Softness" is achieved through the use of **chamfered corners** (angled 45-degree cuts) on buttons and containers, simulating carved stone or wood. Never use standard CSS border-radius; instead, use clip-paths or sprite-based border images to create the characteristic "stair-step" pixel look.

## Components
- **Buttons:** Styled as "Carved Blocks." The default state is a raised terra-cotta block; the hover state adds a golden "glow" inner border; the active (pressed) state shifts the content 2px down and right.
- **Input Fields:** Styled as "Tied Fabric" or "Wooden Tablets." Use a parchment-colored background (`oxala-white`) with a dark inner shadow to simulate an indentation in the wood.
- **Chips/Badges:** Small rectangular tags with adire-inspired patterns. Use `ogum-green` for positive stats and `exu-red` for negative ones.
- **Cards:** These are "Palace Tablets." They must feature a decorative header with a forged iron texture and a footer that looks like a thatched fringe.
- **Icons:** All icons must be hand-painted sprites.
    - **Hammer:** Blacksmith/Crafting.
    - **Staff:** Palace/Quests.
    - **Gourd:** Library/Knowledge.
    - **Cowrie Shells:** Currency/Market.
- **Selection Indicators:** Use a small "Golden Spear" or "Burning Flame" sprite that floats to the left of the selected list item, animated with a simple 2-frame "bounce."